<!DOCTYPE html>
<html>
 
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
        <script src="./ini_JS.js"></script>
</head>
 
<body>
    <center>
    <table class="table">
        <tr>
            <th>Nama</th>
            <th>NIM</th>
            <th>Angkatan</th>
            <th>Jenis Kelamin</th>
        </tr>
        <?php
            $conn = mysqli_connect('localhost','root','12345','list_mahasiswa');
            $result = mysqli_query($conn,"SELECT nama, nim, angkatan, jenis_kelamin from mahasiswa");
            
            if (mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    echo "<tr><td>".$row['nama']."</td><td>".$row['nim']."</td><td>".$row['angkatan']."</td><td>".$row['jenis_kelamin']."</td></tr>";
                }
            }
            mysqli_close($conn);

        ?>
    </table>

    </center>
</body>
 