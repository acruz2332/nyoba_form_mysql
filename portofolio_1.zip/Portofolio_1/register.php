<?php
include 'index.html';

$conn = mysqli_connect("localhost", "root", "12345","list_mahasiswa");

// Check connection
if($conn === false){
    die("ERROR: Could not connect. "
        . mysqli_connect_error());
}

$nama = $_REQUEST['nama'];
$nim = $_REQUEST['nim'];
$angkatan = $_REQUEST['akt'];
$jk = $_REQUEST['jk'];

$sql = "INSERT INTO mahasiswa values ('$nama', '$nim', '$angkatan', '$jk')";

if(mysqli_query($conn, $sql)){
    echo "<script>window.alert('Data telah ditambahkan!')</script>";
}
mysqli_close($conn);
?>
